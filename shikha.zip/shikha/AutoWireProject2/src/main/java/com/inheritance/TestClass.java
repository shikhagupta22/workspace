package com.inheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("inher.xml");
		Person p=(Person) context.getBean("person");
		System.out.println(p);
		Employee e=(Employee) context.getBean("emp");
		System.out.println(e);

	}

}
