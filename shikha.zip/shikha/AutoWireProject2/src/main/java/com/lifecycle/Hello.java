package com.lifecycle;

public class Hello 
{
	private String hello;
    Hello()
    {
    	System.out.println(" Object Created Hello");
    }
	public String getHello() {
		return hello;
	}

	public void setHello(String hello) {
		this.hello = hello;
	}
	
	

}
