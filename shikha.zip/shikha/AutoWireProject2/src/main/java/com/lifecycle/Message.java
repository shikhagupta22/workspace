package com.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Message implements InitializingBean,DisposableBean
{
	private String message;
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public void destroy() throws Exception 
	{
		System.out.println("Destroyed...");
		
	}

	@Override
	public void afterPropertiesSet() throws Exception 
	{
		System.out.println("Initialized..");
		
	}
	Message()
	{
		System.out.println("Object Created...");
	}
	public void myInit()
	{
		System.out.println("User declared initialization");
	}
	public void myDestroy()
	{
		System.out.println("User declared destroyed");
	}


}
