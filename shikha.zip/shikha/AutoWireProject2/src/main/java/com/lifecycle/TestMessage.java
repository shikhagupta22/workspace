package com.lifecycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMessage 
{
	public static void main(String[] args) 
	{
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("lifecycle.xml");
		Message msg1=(Message)context.getBean("msg1");
		System.out.println(msg1.getMessage());
		Hello msg=(Hello) context.getBean("hello");
		System.out.println(msg.getHello());
		context.registerShutdownHook();
		/*BeanFactory bean=new XmlBeanFactory(new FileSystemResource("lifecycle.xml"));
		Hello msg=(Hello) bean.getBean("msg");
		System.out.println(msg.getHello());*/
	}

}
