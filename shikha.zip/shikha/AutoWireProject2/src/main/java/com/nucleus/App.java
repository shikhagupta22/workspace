package com.nucleus;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context=new AnnotationConfigApplicationContext(SetBeanConf.class);
       Customer cust=(Customer) context.getBean("cust");
       cust.setcName("shikha");
       cust.setcContact("9810113264");
       Address adrs=(Address) context.getBean("adrs");
       adrs.setCity("Noida");
       adrs.setState("UP");
       //cust.setAdrs(adrs);
       //System.out.println("Customer name "+cust.getcName());
       //System.out.println("Customer Contact "+cust.getcContact());
      // System.out.println("Customer Address "+adrs);
       System.out.println(cust);
    }
}
