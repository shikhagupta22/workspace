package com.nucleus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Customer 
{
	private String cName;
	private String cContact;
	@Autowired
	private Address adrs;
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcContact() {
		return cContact;
	}
	public void setcContact(String cContact) {
		this.cContact = cContact;
	}
	public Address getAdrs() {
		return adrs;
	}
	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	@Override
	public String toString() {
		return "Customer [cName=" + cName + ", cContact=" + cContact
				+ ", adrs=" + adrs + "]";
	}
	

}
