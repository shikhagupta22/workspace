package com.nucleus;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SetBeanConf 
{
	@Bean(name="cust")
	public Customer cust()
	{
		return new Customer();
	}
	@Bean(name="adrs")
	public Address ad()
	{
		return new Address();
	}

}
