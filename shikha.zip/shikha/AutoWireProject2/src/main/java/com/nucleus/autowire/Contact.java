package com.nucleus.autowire;

public class Contact 
{
	private String code;
	private String number;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Contact [code=" + code + ", number=" + number + "]";
	}
}
