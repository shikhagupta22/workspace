package com.nucleus.autowire;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer 
{
	private String cName;
	private Contact contact;
	Customer(Contact contact)
	{
		this.contact=contact;
		
	}
	Customer(String cName,Contact contact)
	{
		this.cName=cName;
		this.contact=contact;
		
	}
	public String getcName() {
		return cName;
	}
	public Contact getContact() {
		return contact;
	}
	@Override
	public String toString() {
		return "Customer [cName=" + cName + ", contact=" + contact + "]";
	}
	

}
