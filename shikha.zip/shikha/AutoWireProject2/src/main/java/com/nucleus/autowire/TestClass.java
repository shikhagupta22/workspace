package com.nucleus.autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("source.xml");
		Customer cust=(Customer) context.getBean("cust");
		Contact con=cust.getContact();
		System.out.println(cust+" "+con.getCode()+" "+con.getNumber());
	}

}
