package com.nucleus.inheritance;

public class Employee 
{
	private String eId;
	private Address adrs;
	private Org org;
	private Contact contact;
	public String geteId() {
		return eId;
	}
	public void seteId(String eId) {
		this.eId = eId;
	}
	public Address getAdrs() {
		return adrs;
	}
	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	public Org getOrg() {
		return org;
	}
	public void setOrg(Org org) {
		this.org = org;
	}
	public Contact getContact() {
		return contact;
	}
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", adrs=" + adrs + ", org=" + org
				+ ", contact=" + contact + "]";
	}
	

}
