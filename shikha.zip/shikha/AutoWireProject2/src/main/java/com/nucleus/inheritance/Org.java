package com.nucleus.inheritance;

public class Org 
{
	private String oName;
	private String city;
	public String getoName() {
		return oName;
	}
	public void setoName(String oName) {
		this.oName = oName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Org [oName=" + oName + ", city=" + city + "]";
	}
	

}
