package com.nucleus.inheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp 
{
	public static void main(String[] args)
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("spring1.xml");
		Customer c1=(Customer) context.getBean("c1");
		System.out.println(c1.getcId()+" "+c1.getcName());
		Customer cust=(Customer) context.getBean("cust");
		System.out.println(cust.getcId()+" "+cust.getcName());

	}

}
