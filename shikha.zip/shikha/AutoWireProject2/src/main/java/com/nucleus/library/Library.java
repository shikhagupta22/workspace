package com.nucleus.library;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Library
{
	private String libName;
	@Autowired
	@Qualifier("adrs")
	private Address adrs;
	private Map<Integer,Book> map;
	public String getLibName() {
		return libName;
	}
	public void setLibName(String libName) {
		this.libName = libName;
	}
	public Address getAdrs() {
		return adrs;
	}
	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	public Map<Integer, Book> getMap() {
		return map;
	}
	public void setMap(Map<Integer, Book> map) {
		this.map = map;
	}
	@Override
	public String toString() {
		return "Library [libName=" + libName + ", adrs=" + adrs + ", map="
				+ map + "]";
	}
	

}
