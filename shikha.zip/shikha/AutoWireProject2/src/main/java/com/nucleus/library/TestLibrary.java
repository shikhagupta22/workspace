package com.nucleus.library;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestLibrary 
{
	public static void main(String[] args) 
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("map.xml");
		Library lib=(Library) context.getBean("lib");
		System.out.println(lib);
		Map<Integer,Book> map=lib.getMap();
		for(Map.Entry m:map.entrySet())
		{
			Book b=(Book) m.getValue();
			System.out.println(m.getValue());
			System.out.println(m.getKey()+" "+b.getBookName()+" "+b.getIsbn()+" "+b.getQuantity());
		}

	}

}
