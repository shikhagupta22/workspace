package com.nucleus.newPack;

public class Contact 
{
	private String stdCode;
	private String number;
	public String getStdCode() {
		return stdCode;
	}
	public void setStdCode(String stdCode) {
		this.stdCode = stdCode;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Contact [stdCode=" + stdCode + ", number=" + number + "]";
	}
	

}
