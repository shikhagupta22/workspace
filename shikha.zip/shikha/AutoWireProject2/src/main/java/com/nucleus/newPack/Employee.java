package com.nucleus.newPack;

import java.util.List;

public class Employee 
{
	private String eId;
	private String eName;
	private List<Contact> con;
	public String geteId() {
		return eId;
	}
	public void seteId(String eId) {
		this.eId = eId;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public List<Contact> getCon() {
		return con;
	}
	public void setCon(List<Contact> con) {
		this.con = con;
	}
/*	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", eName=" + eName + ", con=" + con
				+ "]";
	}*/
	
	

}
