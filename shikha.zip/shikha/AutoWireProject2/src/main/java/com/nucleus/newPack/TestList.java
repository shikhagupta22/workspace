package com.nucleus.newPack;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestList {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("list.xml");
		Employee e=(Employee) context.getBean("emp1");
		List<Contact> c=e.getCon();
		Iterator itr=c.iterator();
		System.out.println(e.geteId()+" "+e.geteName()+" "+e.getCon());
		while(itr.hasNext())
		{
			Contact contact=(Contact) itr.next();
			System.out.println("StdCode :" +contact.getStdCode()+"Number: "+contact.getNumber());
			
		}
		//System.out.println();
	}

}
