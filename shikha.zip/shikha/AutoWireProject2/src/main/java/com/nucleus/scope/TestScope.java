package com.nucleus.scope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestScope 
{
	public static void main(String[] args) 
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("scope.xml");
		Employee emp=(Employee) context.getBean("emp");
		Employee emp1=(Employee) context.getBean("emp");
		System.out.println(emp);
		System.out.println(emp1);
		if(emp==emp1)
		{
			System.out.println("equals: Singleton Scope:default");
		}
		else
		{
			System.out.println("Prototype Scope:not equals");
		}
		emp1.seteId(102);
		emp1.seteName("puja");
		System.out.println(emp);
		System.out.println(emp1);

	}

}
