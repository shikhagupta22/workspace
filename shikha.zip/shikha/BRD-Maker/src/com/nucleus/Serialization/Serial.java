package com.nucleus.Serialization;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.nucleus.pojo.Customer;
import com.nucleus.pojo.CustomerBase;

public class Serial 
{
	public void getSerial()
	{
		CustomerBase customer=new Customer();
		  FileOutputStream fout = null;
		try {
			fout = new FileOutputStream("f.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		  ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(fout);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		  
		  try {
			out.writeObject(customer);
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		    
		  System.out.println("success");  
	}

}
