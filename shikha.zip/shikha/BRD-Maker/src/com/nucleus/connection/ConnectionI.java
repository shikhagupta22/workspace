package com.nucleus.connection;

import java.io.IOException;
import java.sql.Connection;

public interface ConnectionI 
{
	public Connection getConnection() throws IOException;

}
