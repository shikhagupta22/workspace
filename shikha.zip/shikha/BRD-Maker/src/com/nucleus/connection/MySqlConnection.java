package com.nucleus.connection;

import java.sql.Connection;

public class MySqlConnection implements ConnectionI 
{

	@Override
	public Connection getConnection() 
	{
		// TODO Auto-generated method stub
		return null;
	}

}
