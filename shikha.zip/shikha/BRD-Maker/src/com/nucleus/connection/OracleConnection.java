package com.nucleus.connection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class OracleConnection implements ConnectionI
{
	Connection conn=null;
	//public void getProp() throws IOException
	
    @Override
	public Connection getConnection()
	{
    	String url=null,user=null,pass=null;
		{
			FileReader reader=null;
		try 
		{
		   reader=new FileReader("d:/shikha/BRD-Maker/src/Conn.properties");
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}  
		Properties p=new Properties();
		try {
			p.load(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		url=p.getProperty("url");
		user=p.getProperty("user");
		pass=p.getProperty("pass");
		}
		
		try 
		{
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn=DriverManager.getConnection(url,user,pass);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return conn;
	}

}
