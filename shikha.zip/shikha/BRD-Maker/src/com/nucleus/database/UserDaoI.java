package com.nucleus.database;

public interface UserDaoI 
{
	public int login(String name,String pass);
}
