package com.nucleus.pojo;

public class User 
{

}
