package com.nucleus.service;

import java.util.ArrayList;

import com.nucleus.pojo.Customer;

public interface ServiceCustomerI 
{
	public int validId(String id);
	public int insert(Customer customer);
	public ArrayList<Customer> viewAll();
	public Customer view(String code);
	public int delete(String code);
	public Customer update(String code);
	public int updateDo(Customer customer);
	public ArrayList<Customer> viewDate(String createdate, String status);

}
