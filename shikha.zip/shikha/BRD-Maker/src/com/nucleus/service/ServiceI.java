package com.nucleus.service;

public interface ServiceI 
{
	public int login(String name, String pass);

}
