package com.nucleus.dao;

import java.sql.Connection;

import com.nucleus.pojo.CustomerPojo;

public class Xml implements DaoI  
{

	@Override
	public void insert(CustomerPojo cp,Connection conn) 
	{
		
	}

}
