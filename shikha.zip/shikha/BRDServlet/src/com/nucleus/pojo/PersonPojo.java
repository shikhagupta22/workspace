package com.nucleus.pojo;

public class PersonPojo
{
	private String Code,Name,Ad1,Contact;
	public String getCode() {
		return Code;
	}
	public void setCode(String code) {
		Code = code;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAd1() {
		return Ad1;
	}
	public void setAd1(String ad1) {
		Ad1 = ad1;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	

}
