package com.nucleus.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database 
{
	OracleConnection c=new OracleConnection();
	Connection conn=c.getConnection();
	public int check(String name,String pass)
	{
		try 
		{
			PreparedStatement ps=null;
			ResultSet rs=null;
			ps=conn.prepareStatement("select * from vendor1");
			rs=ps.executeQuery();
			System.out.println(" "+name +""+pass);

			if(rs!=null)
			{
			while(rs.next())
			{
				System.out.println(rs.getString(1));
				if((rs.getString(1).equals(name))&&(rs.getString(2).equals(pass)))
			
				{
				System.out.println("Value matched");
				return 1;
				}	
				System.out.println("false");
				
				//rs.next();
			}
		}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return 0;
		
		
		
	}

}
