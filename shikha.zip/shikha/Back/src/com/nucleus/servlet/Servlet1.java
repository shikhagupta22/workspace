package com.nucleus.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.service.Database;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String user=request.getParameter("user");
		String pass=request.getParameter("pass");
		Database d=new Database();
		int val=d.check(user ,pass);
		if(val==1)
		{
            PrintWriter p=response.getWriter();
			p.println("Credentials Matched");
			RequestDispatcher rd=request.getRequestDispatcher("success.html");
			rd.forward(request,response);
		}
		else
		{
			PrintWriter p=response.getWriter();
			p.println("Invalid login");
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.include(request,response);
					}
	}

}
