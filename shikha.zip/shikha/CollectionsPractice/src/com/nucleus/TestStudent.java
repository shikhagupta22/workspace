package com.nucleus;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestStudent {

	public static void main(String[] args) 
	{
		Student s1=new Student(1,"shikha",23);
		Student s2=new Student(2,"rahul",24);
		Student s3=new Student(3,"tripti",25);
		List<Student> list=new ArrayList<Student>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		Iterator itr=list.iterator();
		while(itr.hasNext())
		{
			Student s=(Student) itr.next();
			System.out.println(s.rollno +" "+s.name+" "+s.age);
		}
		
	}

}
