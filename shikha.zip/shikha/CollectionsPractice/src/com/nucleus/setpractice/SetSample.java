package com.nucleus.setpractice;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SetSample 
{
	public static void main(String args[])
	{
		Map<Integer,String> set1=new HashMap<Integer,String>();
		set1.put(28,"Shikha");
		set1.put(29,"Shi");
		set1.put(30,"tripti");
		set1.put(31,"S");
		//System.out.println(set1.hashCode());
		Set<Map.Entry<Integer,String>> set=set1.entrySet();
		for(Map.Entry<Integer,String> i:set)
		{
			System.out.println(i);
		}
	}

}
