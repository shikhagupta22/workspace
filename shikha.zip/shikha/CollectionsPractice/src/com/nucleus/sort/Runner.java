package com.nucleus.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Runner 
{
	public static void main(String args[])
	{
		List<Laptop> lap=new ArrayList<Laptop>();
		lap.add(new Laptop("apple",12,890));
		lap.add(new Laptop("acer",16,800));
		lap.add(new Laptop("lenova",32,990));
		Comparator<Laptop> com=new Comparator<Laptop>()
				{

					@Override
					public int compare(Laptop l1,Laptop l2) 
					{
						int val=l1.getBrand().compareTo(l2.getBrand());
						if(val>0)
						{
							return 1;
						}	
						return -1;
					}
			
				};
		Collections.sort(lap,com);
		for(Laptop l:lap)
		{
			System.out.println(l);
		}
	}

}
