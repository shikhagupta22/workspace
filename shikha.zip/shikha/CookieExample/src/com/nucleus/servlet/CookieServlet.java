package com.nucleus.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieServlet
 */
@WebServlet("/CookieServlet")
public class CookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CookieServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String name=request.getParameter("user");
		String name1=request.getParameter("user1");
		String name2=request.getParameter("user2");
		String name3=request.getParameter("user3");
		String name4=request.getParameter("user4");
		String name5=request.getParameter("user5");
		Cookie cookie=new Cookie("a", name);
		Cookie cookie1=new Cookie("b", name1);
		Cookie cookie2=new Cookie("c", name2);
		Cookie cookie3=new Cookie("d", name3);
		Cookie cookie4=new Cookie("e", name4);
		Cookie cookie5=new Cookie("f", name5);
		response.addCookie(cookie);
		response.addCookie(cookie1);
		response.addCookie(cookie2);
		response.addCookie(cookie3);
		response.addCookie(cookie4);
		response.addCookie(cookie5);
		RequestDispatcher rd=request.getRequestDispatcher("CookieServlet2");
		rd.forward(request, response);
		
		
	}

}
