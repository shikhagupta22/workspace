package com.nucleus;

public class Employee 
{
	private int empId;
	private String empName;
	private Address adrs;
	Employee()
	{
		
	}
	Employee(int empId)
	{
		this.empId=empId;
		System.out.println(empId);
		
	}
	public Employee(int empId, String empName, Address adrs) {
		this.empId = empId;
		this.empName = empName;
		this.adrs = adrs;
	}
	Employee(int empId,String empName)
	{
		this.empId=empId;
		this.empName=empName;
		//System.out.println(empId);
		
	}
	public Address getAdrs() {
		return adrs;
	}
	public void setAdrs(Address adrs) {
		this.adrs = adrs;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", adrs="
				+ adrs + "]";
	}
	

}
