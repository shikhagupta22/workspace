package com.nucleus.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.nucleus.entity.User;
import com.nucleus.service.UserService;

@Controller
public class UserController 
{
	@Autowired
	UserService userService;
	@RequestMapping(value="/welcomeadmin/new", method=RequestMethod.GET)
	public ModelAndView newUser()
	{
		return new ModelAndView("userRegistration","user",new User());
	}
	@RequestMapping(value="/welcomeadmin/new", method=RequestMethod.POST)
	public ModelAndView newUserEnter(@ModelAttribute("user") @Valid User user, BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("userRegistration","user",user);
		}
	/*	Hobbies hobby=new Hobbies();
		hobby.setHobby1("Dance");
		hobby.setHobby2("Singing");
		List<Hobbies> hobbies=new ArrayList<Hobbies>();
		hobbies.set(1,hobby);
		user.getHobbies().set(1,hobby);*/
		userService.insert(user);
		return new ModelAndView("userSuccess");
	}

}
