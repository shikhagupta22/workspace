package com.nucleus.dao;

import com.nucleus.entity.User;

public interface UserDao {

	public void insert(User user);

}
