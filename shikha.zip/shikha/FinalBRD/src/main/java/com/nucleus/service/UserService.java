package com.nucleus.service;

import com.nucleus.entity.User;

public interface UserService {

	void insert(User user);

}
