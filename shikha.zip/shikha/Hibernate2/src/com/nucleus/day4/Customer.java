package com.nucleus.day4;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CustomerPersist")
@DiscriminatorValue(value = "Customer")
public class Customer extends Person
{
	@Column(name="EMERGENCY_CONTACT")
	private String contact;
	private int noOfPurchase;
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public int getNoOfPurchase() {
		return noOfPurchase;
	}
	public void setNoOfPurchase(int noOfPurchase) {
		this.noOfPurchase = noOfPurchase;
	}
	

}
