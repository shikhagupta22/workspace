package com.nucleus.day4;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestInheritance 
{
	public static void main(String args[])
	{
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	Transaction t=session.beginTransaction();
	Person person=new Person();
	Customer cust=new Customer();
	cust.setName("Rahul");
	cust.setContact("9876543210");
	cust.setNoOfPurchase(23);
	person.setName("Shikha");
	//session.save(person);
	session.save(cust);
	t.commit();
	}

}
