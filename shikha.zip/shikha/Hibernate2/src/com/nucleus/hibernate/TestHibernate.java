package com.nucleus.hibernate;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestHibernate 
{
	@SuppressWarnings("unchecked")
	public static void main(String args[])
	{
		System.out.println("ENTER VALUES TO PERFORM CRUD OPERATIONS");
		System.out.println("1.TO VIEW ALL THE DETAILS");
		System.out.println("2.TO VIEW BY ID");
		System.out.println("3.TO REMOVE EMPLOYEES");
		System.out.println("4.TO UPDATE ON CERTAIN CRITERIA");
		System.out.println("5.TO SAVE THE DATA");
		System.out.println("6.TO VIEW ALL DETAILS");
		Scanner sc=new Scanner(System.in);
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:Query query=session.createQuery("from Employee");
		      List<Employee> list=query.list();
		      for(Employee e:list)
		      {
		    	  System.out.println(e.geteId()+" "+e.geteName()+" "+e.geteSalary()+" "+e.geteDesignation()+" "+e.getAddress()+" "+e.getDeptId());
		      }
		  	  t.commit();
			  session.close();
			  factory.close();
			  break;
		case 2:Employee e=(Employee) session.get(com.nucleus.hibernate.Employee.class,1);
		       System.out.println(e);
	  	       t.commit();
			   session.close();
			   factory.close();
			   break;
		case 3:Employee e1=(Employee) session.get(com.nucleus.hibernate.Employee.class,7);	   
		       session.delete(e1);
		       t.commit();
			   session.close();
			   factory.close();
			   break;
		case 4:Query query1=session.createQuery("from Employee where esalary=:salary");
		       query1.setParameter("salary","150005000");
		       Employee emp1=(Employee) query1.uniqueResult();
		       List<Employee> list1=query1.list();
		        for(Employee emp:list1)
		        {
		            //emp.seteDesignation("Engineer");
			        emp.seteSalary("13000");
			        session.update(emp);
			        System.out.println(emp);
			    }
		        t.commit();
		        session.close();
			    factory.close();
		        break;
		      
		 case 5:Address adrs1=new Address();
		       adrs1.setCity("Kanpur");
		       adrs1.setState("UP");
		       Address adrs2=new Address();
		       adrs2.setCity("Kanpur");
		       adrs2.setState("UP");
		       Department dept=new Department();
		       dept.setDeptName("Technical");
		       dept.setLocation("Noida");
		       Employee emp=new Employee();
		       emp.seteName("Tripti");
		       emp.seteSalary("15000");
		       emp.getAddress().add(adrs1);
		       emp.getAddress().add(adrs2);
		       emp.seteDesignation("Engineer");
		       emp.setDeptId(dept);
		       session.save(emp);
		       t.commit();
		       session.close();
		       factory.close();
		       break;
		case 6:Query query2=session.createSQLQuery(" select * from employee_Nucleus inner join dept_Nucleus on employee_Nucleus.deptid_deptid=dept_Nucleus.deptid where employee_Nucleus.eid=1");
		//query2.setParameter("id",1);
		//int count=query2.executeUpdate();
		//System.out.println(count);
		       Object e2=query2.uniqueResult();
		      // Employee emp2=(Employee)e2;
		       //System.out.println(e2.getClass());
		}

   	//Address adrs1=new Address();
/*		adrs1.setCity("Old Delhi");
		adrs1.setState("Delhi");
		Address adrs2=new Address();
		adrs2.setCity("Noida");
		adrs2.setState("UP");
		Department dept=new Department();
		dept.setDeptName("Technical");
		dept.setLocation("Noida");
		Employee emp=new Employee();
		emp.seteName("Shubham");
		emp.seteSalary("1000000");
		emp.getAddress().add(adrs1);
		emp.getAddress().add(adrs2);
		emp.seteDesignation("Engineer");
		emp.setDeptId(dept);
		session.save(emp);*/
		/*Employee e=(Employee) session.get(com.nucleus.hibernate.Employee.class,5);*/
/*		e.seteDesignation("Engineer");
		session.update(e);*/
/*   	    Employee adrs=(Employee) session.get(com.nucleus.hibernate.Employee.class,7);
   	    adrs.seteSalary("8000");
   	    session.update(adrs);*/
	}

}
