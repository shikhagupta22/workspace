package com.nucleus.day4;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CustomerPersist")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq23")
	@SequenceGenerator( initialValue=23,allocationSize=23,name="seq23" )
	private int id;
	private String name;
	private String contact;
	@ElementCollection(fetch=FetchType.EAGER)
	private List<Address3> adrs3=new ArrayList<Address3>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public List<Address3> getAdrs3() {
		return adrs3;
	}
	public void setAdrs3(List<Address3> adrs3) {
		this.adrs3 = adrs3;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", contact=" + contact + ", adrs3=" + adrs3 + "]";
	}
	
	
	

}
