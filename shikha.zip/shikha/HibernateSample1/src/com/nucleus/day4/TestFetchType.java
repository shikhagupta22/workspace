package com.nucleus.day4;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestFetchType 
{
	public static void main(String Args[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		Customer customer=(Customer) session.get(com.nucleus.day4.Customer.class,23);
		System.out.println(customer);
/*		Address3 adrs=new Address3();
		adrs.setCity("Kanpur");
		adrs.setState("UP");
		Address3 adrs1=new Address3();
		adrs1.setCity("Lucknow");
		adrs1.setState("UP");
		customer.setName("Tripti");
		customer.setContact("9098765430");
		customer.getAdrs3().add(adrs);
		customer.getAdrs3().add(adrs1);
		session.persist(customer);
		//session.get(com.nucleus.day4.Customer.class,)
*/		t.commit();
		session.close();
	}

}
