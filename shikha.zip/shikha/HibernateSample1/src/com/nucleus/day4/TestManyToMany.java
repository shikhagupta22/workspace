package com.nucleus.day4;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestManyToMany 
{
	public static void main(String Args[])
	{
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	Transaction t=session.beginTransaction();
	Address2 adrs=new Address2();
    adrs.setCity("Lucknow");
    adrs.setState("UP"); 
    Address2 adrs1=new Address2(); //v1
    adrs1.setCity("Kanpur");
    adrs1.setState("UP");
	Vendor vendor=new Vendor();
	vendor.setVname("Shikha");
	vendor.setContact("9810113264");
	vendor.getAddress().add(adrs);
	vendor.getAddress().add(adrs1);
	Vendor vendor1=new Vendor();
	vendor1.setVname("Tripti");
	vendor1.setContact("8802345678");
	vendor1.getAddress().add(adrs);
	vendor1.getAddress().add(adrs1);
	adrs.getVendor().add(vendor);
	adrs1.getVendor().add(vendor);
	adrs.getVendor().add(vendor1);
	adrs1.getVendor().add(vendor1);
	session.save(vendor);
	session.save(vendor1);
	t.commit();
	session.close();
	factory.close();
	
	}

}
