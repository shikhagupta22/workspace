package com.nucleus.day4;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="VendorPersist")
public class Vendor 
{
	@Id
	@GeneratedValue
	private int vId;
	private String vname;
	private String Contact;
	@ManyToMany(cascade=CascadeType.ALL)
	private List<Address2> address=new ArrayList<Address2>();
	public int getvId() {
		return vId;
	}
	public void setvId(int vId) {
		this.vId = vId;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public List<Address2> getAddress() {
		return address;
	}
	public void setAddress(List<Address2> address) {
		this.address = address;
	}

	

}
