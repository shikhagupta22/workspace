package com.nucleus.hibernate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employee_shikha")
public class Employee 
{
	@Id
	@GeneratedValue
	private int id;
	private String name;
	@ElementCollection
	private List<Address> adrs=new ArrayList<Address>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Address> getAdrs() {
		return adrs;
	}
	public void setAdrs(List<Address> adrs) {
		this.adrs = adrs;
	}

	

}
