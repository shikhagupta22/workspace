package com.nucleus.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestEmployee 
{
	public static void main(String Args[])
	{
	Configuration cfg=new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	Transaction transaction=session.beginTransaction();
/*	Address adrs=new Address();
	adrs.setCity("Kanpur");
	adrs.setState("UP");
	Address adrs1=new Address();
	adrs1.setCity("Lucknow");
	adrs1.setState("UP");
	Employee e=new Employee();
	e.setName("Shikha");
    e.getAdrs().add(adrs);
    e.getAdrs().add(adrs1);
	session.persist(e);*/
	Query query=session.createQuery("from Employee");
	@SuppressWarnings("unchecked")
	List<Employee> list=query.list();
	for(Employee e1:list)
	{
		System.out.println(e1.getId()+" "+e1.getName());
	}
	transaction.commit();
	session.close();
	
	factory.close();
	}

}
