package com.nucleus.dao;

import java.util.ArrayList;

import com.nucleus.pojo.Customer1;

public interface CustomerDAOI 
{
	public ArrayList<Customer1> fetchAll();

}
