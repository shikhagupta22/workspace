package com.nucleus;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
    	Employee e=(Employee) context.getBean("bean1");
    	System.out.println(e.geteId()+" "+e.geteName());
    	Employee e1=(Employee) context.getBean("bean2");
    	System.out.println(e1.geteId()+" "+e1.geteName());
    }
}
