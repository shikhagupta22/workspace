package com.nucleus.lifecycle;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.MessageSource;

public class TestInit implements BeanPostProcessor 
{
	@Autowired
	private MessageSource msg;
	@Override
	public Object postProcessAfterInitialization(Object arg0, String arg1)
			throws BeansException 
			{
		System.out.println("After Initialization");
		return arg0;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException 
			{
		//this.msg.getMessage("employee.eid", new Object[]{"101"}, null, null);
		//this.msg.getMessage("employee.eid1", new Object[]{1,"102"}, null, null);
		if(bean instanceof Employee)
		{
			((Employee) bean).seteId(this.msg.getMessage("employee.eid", new Object[]{"101"}, null, null));
			System.out.println(this.msg.getMessage("employee.eid", new Object[]{"101"}, null, null));
		}
		return bean;
		
		
	}

}
