package com.nucleus.prop;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
	public static void main(String args[])
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		TestProp tp=(TestProp) context.getBean("test");
		List<String> list=tp.show();
		Employee e=(Employee) context.getBean("emp");
		e.seteId(list.get(0));
		e.seteName(list.get(1));
		Employee e1=(Employee) context.getBean("emp");
		e1.seteId(list.get(2));
		e1.seteName(list.get(3));
		System.out.println(e);
		System.out.println(e1);
	}

}
