package com.nucleus.prop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

public class TestProp 
{
	@Autowired
	private MessageSource msg;
	public List<String> show()
	{
		List<String> list = new ArrayList<String>();
		list.add(this.msg.getMessage("employee.eid", null, null,null));
		list.add(msg.getMessage("employee.ename", null, null,null));
		list.add(msg.getMessage("employee.eid1", null, null,null));
		list.add(msg.getMessage("employee.ename1", null, null,null));
		return list;
	}
	
}
