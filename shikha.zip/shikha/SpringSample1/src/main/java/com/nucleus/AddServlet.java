package com.nucleus;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AddServlet 
{
	@RequestMapping("/add")
	public String add()
	{
		return "display";
	}
	@RequestMapping("/getPage")
	public String getPage()
	{
		return "add";
	}

}
