package com.nucleus.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class TestController 
{
	@RequestMapping(value="/*")
	public String home()
	{
		return "index";
	}
	@RequestMapping(value="/logout")
	public String logout()
	{
		return "logout";
	}
    @RequestMapping(value="/welcome")
    public String welcome()
    {
    	return "welcome";
    }
    @RequestMapping(value="/welcomemaker")
    public String welcomemaker()
    {
    	return "welcomemaker";
    }
    @RequestMapping(value="/form")
    public String customform()
    {
    	return "form";
    }

}
