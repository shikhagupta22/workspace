package com.nucleus.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.Pojo.Vendor;
import com.nucleus.sevice.VendorServiceI;

@Controller
public class TestController 
{
	@Autowired
	VendorServiceI vendorServiceI;
	@RequestMapping("insert")
	public String insert()
	{
		return "insert";
	}
	@RequestMapping("view")
	public String view()
	{
		return "view";
	}
	@RequestMapping("welcome")
	public String welcome()
	{
		return "welcome";
	}
	@RequestMapping("delete")
	public String delete()
	{
		return "delete";
	}
	@RequestMapping("update")
	public String update()
	{
		return "update";
	}
	@RequestMapping(value="viewbyid", method=RequestMethod.GET)
	public ModelAndView viewById(@RequestParam("id") String id)
    {
		int id1=Integer.parseInt(id);
		Vendor vendor=vendorServiceI.view(id1);
		return new ModelAndView("finalview","vendor",vendor);
    }
	@RequestMapping(value="insertvalue",method=RequestMethod.POST)
	public ModelAndView insertvalue(@ModelAttribute("vendor") Vendor vendor)
	{
		int insert=vendorServiceI.insertvalue(vendor);
		return new ModelAndView("finalinsert","vendor",vendor);
	}
	@RequestMapping(value="deletedata",method=RequestMethod.GET)
	public String deletedata(@RequestParam("id") String id)
	{
		int id1=Integer.parseInt(id);
		int delete=vendorServiceI.deletedata(id1);
		return "finaldelete";
		
	}
	@RequestMapping(value="updatedata",method=RequestMethod.GET)
	public ModelAndView updatedata(@RequestParam("id") String id)
	{
		return new ModelAndView("update1","id",id);
	}
	@RequestMapping(value="finalupdate",method=RequestMethod.POST)
	public ModelAndView finalupdate(@ModelAttribute("vendor") Vendor vendor)
	{
		int update=vendorServiceI.finalupdate(vendor);
		return new ModelAndView("finalupdate");
	}
	@RequestMapping(value="viewall",method=RequestMethod.GET)
	public ModelAndView viewAll()
	{
		List<Vendor> viewAll=vendorServiceI.viewAll();
		return new ModelAndView("viewAll","list",viewAll);
		
	}
	

}
