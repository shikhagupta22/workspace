package com.nucleus.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nucleus.Pojo.Vendor;
import com.nucleus.mapper.VendorMapper;

@Repository
public class VendorDao implements VendorDaoI
{
	@Autowired
	JdbcTemplate jdbcTemplate;
	public Vendor view(int id) 
	{
		@SuppressWarnings("unchecked")
		Vendor vendor=(Vendor)jdbcTemplate.queryForObject("Select * from vendor_shikha where vid=?",new Object[]{id}, new VendorMapper());
		return vendor;
		
		
	}
	public int insertvalue(Vendor vendor) 
	{
		int insert=jdbcTemplate.update("insert into vendor_shikha values("+vendor.getvId()+",'"+vendor.getvName()+"')");
		return insert;
	}
	@Override
	public int deletedata(int id) 
	{
		int delete=jdbcTemplate.update("delete from vendor_shikha where vid=?", new Object[]{id});
		return delete;
	}
	@Override
	public int finalupdate(Vendor vendor) 
	{
		int update=jdbcTemplate.update("update vendor_shikha set vname=? where vid=?", new Object[]{vendor.getvName(),vendor.getvId()});
		return update;
	}
	@Override
	public List<Vendor> viewAll() 
	{
		@SuppressWarnings("unchecked")
		List<Vendor> list=jdbcTemplate.query("select * from vendor_shikha",new VendorMapper());
		return list;
	}

}
