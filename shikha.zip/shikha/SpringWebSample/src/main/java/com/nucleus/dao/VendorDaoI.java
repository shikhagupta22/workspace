package com.nucleus.dao;

import java.util.List;

import com.nucleus.Pojo.Vendor;

public interface VendorDaoI {

	public Vendor view(int id);
	public int insertvalue(Vendor vendor);
	public int deletedata(int id);
	public int finalupdate(Vendor vendor);
	public List<Vendor> viewAll();

}
