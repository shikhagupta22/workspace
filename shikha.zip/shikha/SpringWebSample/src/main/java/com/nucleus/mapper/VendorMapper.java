package com.nucleus.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nucleus.Pojo.Vendor;

public class VendorMapper implements RowMapper
{

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		Vendor vendor = new Vendor();
		vendor.setvId(rs.getInt("vId"));
		vendor.setvName(rs.getString("vName"));
		return vendor;
	}

}
