package com.nucleus.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.Pojo.Vendor;
import com.nucleus.dao.VendorDaoI;
@Service
public class VendorService implements VendorServiceI
{
	@Autowired
	VendorDaoI vendorDaoI;
	@Override
	public Vendor view(int id) 
	{
		Vendor vendor=vendorDaoI.view(id);
		return vendor;
		
	}
	@Override
	public int insertvalue(Vendor vendor) 
	{
		int insert=vendorDaoI.insertvalue(vendor);
		return insert;
	}
	@Override
	public int deletedata(int id) 
	{
		int delete=vendorDaoI.deletedata(id);
		return delete;
	}
	@Override
	public int finalupdate(Vendor vendor) 
	{
		int update=vendorDaoI.finalupdate(vendor);
		return update;
	}
	@Override
	public List<Vendor> viewAll() 
	{
		List<Vendor> list=vendorDaoI.viewAll();
		return list;
	}
	

}
