package com.nucleus.sevice;

import java.util.List;

import com.nucleus.Pojo.Vendor;

public interface VendorServiceI 
{
	public Vendor view(int id);
	public int insertvalue(Vendor vendor);
	public int deletedata(int id);
	public int finalupdate(Vendor vendor);
	public List<Vendor> viewAll();

}
