package com.nucleus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.entity.User;
import com.nucleus.service.UserServiceI;

@Controller
public class UserController 
{
	@Autowired
	UserServiceI userService;
	@RequestMapping("/")
	public String mainpage()
	{
		return "view";
	}
	@RequestMapping(value="/insert" ,method=RequestMethod.POST)
	public String insert(@ModelAttribute("user") User user)
	{
		int insert=userService.insert(user);
		return "success";
	}
	@RequestMapping(value="/view" ,method=RequestMethod.POST)
	public ModelAndView view(@RequestParam("user_id") int id)
	{
		User user=userService.view(id);
		return new ModelAndView("successView","user",user);
	}

}
