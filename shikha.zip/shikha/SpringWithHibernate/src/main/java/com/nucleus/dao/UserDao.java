package com.nucleus.dao;

import com.nucleus.entity.User;

public interface UserDao {

	int insert(User user);

	User view(int id);

}
