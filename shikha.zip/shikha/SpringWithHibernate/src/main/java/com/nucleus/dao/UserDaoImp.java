package com.nucleus.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.entity.User;
@Repository
public class UserDaoImp implements UserDao 
{
	@Autowired 
	SessionFactory sessionFactory;

	@Override
	public int insert(User user) 
	{
		sessionFactory.getCurrentSession().save(user);
		return 1;
		
	}

	@Override
	public User view(int id) 
	{
		User user=(User) sessionFactory.getCurrentSession().get("com.nucleus.entity.User",id);
		System.out.println(user);
		return user;
	}

}
