package com.nucleus.service;


import com.nucleus.entity.User;
public interface UserServiceI {

	int insert(User user);

	User view(int id);

}
