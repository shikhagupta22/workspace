package com.nucleus.test;


public class BestBowler 
{
	void inputs(int input1,String input2)
	{
		if(input1==0)
		{
			System.out.println("There are no bowlers");
			
		}
		else
		{
			
			
			
			
		}
	}

}
