package com.nucleus.test;

public class Match 
{
	int m;
	void getOriginalScore(int matchesPlayed,int PlayerScore[])
	{
		for(int i=0;i<=matchesPlayed;i++)
		{
			for(int j=i+1;j<=matchesPlayed-2;j++)
			{
				if(PlayerScore[i]+1==PlayerScore[j])
				{
					if(PlayerScore[j]+1==PlayerScore[j+1])
					{
						PlayerScore[i]=PlayerScore[j];
						PlayerScore[j]=PlayerScore[j+2];
						for(int k=j+1;k<=matchesPlayed-3;k++)
						{
							PlayerScore[k]=PlayerScore[k+2];
							m=matchesPlayed-2;
							
				        }
						
						
						
						
					}
					else
					{
						i++;
						j++;
					}
					
				}
			
				else
				{
					i++;
					j++;
				}
			}
		}
		for(int l=0;l<=matchesPlayed-1;l++)
		{
			System.out.println(PlayerScore[l]);
		}
	}

}
