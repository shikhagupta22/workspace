package com.nucleus.test;

public class MatchTest 
{

	public static void main(String[] args) 
	{
		int matches=6;
		//int arr[]={55 ,99 ,99 ,100, 101, 101 ,34, 35, 36, 5 ,28, 7 ,50 ,50, 51, 52 ,52 ,24 ,13, 14 ,15 ,5 ,6 ,7 ,37 ,31,37 ,38, 39, 36, 40};
		int arr[]={1, 3, 4,5, 6, 8};
		Match m=new Match();
		m.getOriginalScore(matches,arr);

	}

}
