package com.nucleus.test;

public class Matches 
{
	int m;
	void getOriginalScore(int matchesPlayed,int PlayerScore[])
	{
		for(int i=0;i<=matchesPlayed;i++)
		{
			for(int j=i+1;j<=matchesPlayed-2;j++)
			{
				if(PlayerScore[i]+1==PlayerScore[j])
				{
					if(PlayerScore[j+1]==PlayerScore[j])
					{
						PlayerScore[i]=PlayerScore[j];
						PlayerScore[j]=PlayerScore[j+2];
						
						
						for(int k=j+1;k<=matchesPlayed;k++)
						{
							if(k+1<=matchesPlayed-2)
								{PlayerScore[k]=PlayerScore[k+2];
							     m=matchesPlayed-1;}
							else
							{
								continue;
							}
						}
					}
					else
					{
						continue;
					}
				}
				else
				{
					continue;
				}
			}
		
	    }
		for(int l=0;l<=m+1;l++)
		{
			System.out.println(" "+ PlayerScore[l]);
			
		}

}
}
