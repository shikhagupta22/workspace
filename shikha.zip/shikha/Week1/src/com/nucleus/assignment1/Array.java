package com.nucleus.assignment1;

public class Array 
{
	int a2[]=new int[5];
	public int[] copy(int a1[])
	{
		
		for(int i=0;i<5;i++)
		{
			a2[i]=a1[i];
			
		}
		return a2;
	}

	
	public static void main(String[] args) 
	{ 
		int a1[]={1,4,5,6,7};
		Array a=new Array();
		a.copy(a1);
		for(int i=0;i<5;i++)
		{
			System.out.println(a.a2[i]);
			
		}
		
		
		

	}

}
