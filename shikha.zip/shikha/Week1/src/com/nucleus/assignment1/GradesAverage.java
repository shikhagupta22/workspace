package com.nucleus.assignment1;

import java.util.*;
public class GradesAverage 
{
	int numStudents;
	int grades[];

	
	void values() 
	{
		System.out.println("Enter the number of students");
		Scanner sc=new Scanner(System.in);
		numStudents=sc.nextInt();
		grades=new int[numStudents];
		for(int i=0;i<numStudents;i++)
		{
		  System.out.println("Enter the grade for student "+(i+1));
		  grades[i]=sc.nextInt();
		  if(grades[i]>100)
		  {
			  System.out.println("Invalid grade try again.....");
			  System.out.println("Enter the grade for student "+(i+1));
			  grades[i]=sc.nextInt();
			  
		  }
		}
	}
		void avg()
		{
			int sum=0;
			for(int i=0;i<numStudents;i++)
			{
				sum=sum+grades[i];
				
			}
				int avg=sum/numStudents;
				System.out.println("The average is: "+avg);
				
			}
			
			
		}
