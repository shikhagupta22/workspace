package com.nucleus.assignment1;


public class Table 
{
	void print()
	{
		 System.out.println("------------------------------------------------------");
		 
		for(int i=1;i<=9;i++)
		{
			System.out.println(" ");
			for(int j=1;j<=9;j++)
			{
				System.out.print("    "+i*j);
				
				
			}
		}
	}

}
