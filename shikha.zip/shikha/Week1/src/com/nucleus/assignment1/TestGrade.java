package com.nucleus.assignment1;


public class TestGrade 
{

	public static void main(String[] args) 
	{
		GradesAverage g=new GradesAverage();
		g.values();
		g.avg();

	}

}
