package com.nucleus.assignment1;


public class TestTable {

	
	public static void main(String[] args) 
	{
		Table t=new Table();
		t.print();
		

	}

}
