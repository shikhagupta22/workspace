package com.nucleus.assignment2;
import java.util.Random;

public class Account 
{
	String name;
	String accountNumber;
	double accountBalance;


Account(String name,double accountBalance)
    {
	  this.name=name;
	  this.accountBalance=accountBalance;
	
	}
void genAcc()
    {
	   Random rand=new Random();
	   accountNumber=" "+rand.nextInt(10)+rand.nextInt(10)+rand.nextInt(10)+rand.nextInt(10)+rand.nextInt(10);	
    }
void deposit(double deposit)
    {
	  this.accountBalance=this.accountBalance+deposit;
	  System.out.println("Current balance is :"+  this.accountBalance);
	
    }



}
