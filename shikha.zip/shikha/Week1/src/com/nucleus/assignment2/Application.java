package com.nucleus.assignment2;
import java.util.Scanner;

public class Application 
{

	
	public static void main(String[] args) 
	{
		int a;
		do{
		System.out.println("Menu");
		System.out.println("Press 1 for id");
		System.out.println("Press 2 for id and name");
		System.out.println("Press 3 for id ,name and grade");
		System.out.println("Press 4 for id ,name,grade and year");
		System.out.println("Press 5 for exit");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		switch(a)
			{
		case 1:System.out.println("Enter id");
		       String b=sc.next();
		       Student s=new Student(b);
		       s.display();
		       break;
		case 2:System.out.println("Enter id and name");
	       String c=sc.next();
	       String d=sc.next();
	       Student s1=new Student(c,d);
	       s1.display();
	       break;
		case 3:System.out.println("Enter id,name and grade");
	       String e=sc.next();
	       String f=sc.next();
	       double g=sc.nextDouble();
	       Student s3=new Student(e,f,g);
	       s3.display();
	       break;
		case 4:System.out.println("Enter id,name,grade and hour");
	       String h=sc.next();
	       String i=sc.next();
	       double j=sc.nextDouble();
	       int k=sc.nextInt();
	       Student s4=new Student(h,i,j);
	       s4.display(k);
			break;
		
			}}while(a!=5);
		System.out.println("exiting!!!!");
	      System.exit(0);
		
		

	}

}
