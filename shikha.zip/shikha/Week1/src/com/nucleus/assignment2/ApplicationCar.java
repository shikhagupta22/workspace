package com.nucleus.assignment2;
import java.util.Scanner;

public class ApplicationCar 
{

	
	public static void main(String[] args) 
	{   int a;
		System.out.println("Menu");
		System.out.println("Press 1 for Vehicle");
		System.out.println("Press 2 for Car");
		System.out.println("Press 3 for Convertible");
		System.out.println("Press 4 for Sports Car");
		System.out.println("Press 5 for exit");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		while(a!=5)
		{
		switch(a)
		{ case 1: Vehicle v=new Vehicle();
			      System.out.println("enter the value of number of wheels, model ,passenger and make of car");
			      v.noOfWheel=sc.nextInt();
			      v.model=sc.nextInt();
			      v.noOfPassenger=sc.nextInt();
			      v.make=sc.next();
			      v.display();
			      System.out.println("You can enter another value or press 5 for exit");
	               a=sc.nextInt();
			      break;
		case 2: Car c=new Car();
	            System.out.println("enter the make, model and number of doors of a car");
	            c.make=sc.next();
	            c.model=sc.nextInt();
	            c.noOfDoor=sc.nextInt();
	            c.display();
	            System.out.println("You can enter another value or press 5 for exit");
	               a=sc.nextInt();
	            break;
		case 3: Convertible c1=new Convertible();
	            System.out.println("enter the make, model and number of doors of a car and is hood open(true/false)");
	            c1.make=sc.next();
	            c1.model=sc.nextInt();
	            c1.noOfDoor=sc.nextInt();
	            c1.display();
	            System.out.println("You can enter another value or press 5 for exit ");
	               a=sc.nextInt();
	            break;
		case 4:SportCar s=new SportCar();
               System.out.println("enter the make, model and car");
               s.make=sc.next();
               s.model=sc.nextInt();
               s.display();
               System.out.println("You can enter another value or press 5 for exit");
               a=sc.nextInt();
               break;
		
        default:System.out.println("Please enter valid number");
               a=sc.nextInt();
               break;}
		
			
		          
		
		}
		System.out.println("Exit!!");

	}
	

}
