package com.nucleus.assignment2;

public class BookStore 
{
	Book[] books=new Book[4];
	void init()
	{
		books[0]=new Book("TheAlchemist","Paulo Coelho","ISBN-101",4);
		books[1]=new Book("HeadFirst","Kathy Sierra","ISBN-102",3);
		books[2]=new Book("2states","Chetan Bhagat","ISBN-103",2);
		books[3]=new Book("FewThings Left Unsaid","Sudeep Nagarkar","ISBN-104",6);
		
	}
	void sell(String title,int noOfCopies)
	{
		for(int i=0;i<4;i++)
		{
			if(title.equals(books[i].bookTitle))
		    {
			System.out.println("Book Found");
			   if((books[i].numOfCopies)>noOfCopies)
			   {
				   books[i].numOfCopies=books[i].numOfCopies-noOfCopies;
				   System.out.println(books[i].numOfCopies);
				   return;
				   
			   }
			   else
			   {
				   System.out.println("Number of copies are less");
				   return;
			   }
			
		   }
			
			
			
		}
		System.out.println("books not found");
		
	}
	void order(String isbn,int noOfCopies)
	{
		for(int i=0;i<4;i++)
		{
			if(isbn.equals(books[i].isbn))
		    {
			System.out.println("Book Found");
				   books[i].numOfCopies=books[i].numOfCopies+noOfCopies;
				   System.out.println(books[i].numOfCopies);
				   
			
		   }
			else
			{
				
			}
			
			
			
		}

		
		
		
	}
	void display()
	{
		for(int i=0;i<4;i++)
		{
			System.out.println(books[i].bookTitle+"-"+books[i].author+"-"+books[i].isbn+"-"+books[i].numOfCopies);
		
		}
		
	}

}
