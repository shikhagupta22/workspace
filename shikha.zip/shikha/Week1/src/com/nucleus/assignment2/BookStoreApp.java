package com.nucleus.assignment2;

import java.util.Scanner;

public class BookStoreApp
{

	public static void main(String[] args) 
	{
		
		int x;
		Scanner sc=new Scanner(System.in);
		BookStore bs=new BookStore();
		bs.init();
		
		do
		{
			System.out.println("Menu");
			System.out.println("Press 1 to display all the books");
			System.out.println("Press 2 to sell books");
			System.out.println("Press 3 to order books ");
			System.out.println("Press 0 to exit");
			x=sc.nextInt();
			
			switch(x)
			{
			case 1:
			       bs.display();
			       break;
			case 2:String a;
				   do{
				   System.out.println("Enter the book and number of copies you want to sell");
				   System.out.println("Enter the book name");
			       String book=sc.next();
			       System.out.println("Enter the number of copies");
			       int n=sc.nextInt();
			       bs.sell(book,n);
			       System.out.println("Do u want to sell another book");
			       a=sc.next();
			       }while(a.equals("Y")||a.equals("y"));
				   bs.display();
				   break;
			       
			case 3:String b;
			       do{
			       System.out.println("Enter the book ISBN and number of copies you want to order");
		           String isbn=sc.next();
		           int n=sc.nextInt();
		           bs.order(isbn,n);
		           System.out.println("Do u want to order another book");
		           b=sc.next();
		           }while(b.equals("Y")||b.equals("y"));
			       break;
		    case 0:System.exit(0);
			}
		}while(x==1||x==2||x==3);
		

	}
}	

