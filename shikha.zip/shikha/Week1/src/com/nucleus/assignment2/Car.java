package com.nucleus.assignment2;

public class Car extends Vehicle
{ int noOfDoor;
  void display()
  {
	  System.out.println("Make of car: " +make+" Model: "+ model+ " Number of Doors: "+noOfDoor);
  }

}
