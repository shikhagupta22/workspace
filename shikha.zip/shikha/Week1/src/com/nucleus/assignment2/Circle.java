package com.nucleus.assignment2;

public class Circle 
{    private double radius=1.0;
     private String color="Red";
     Circle()
     {
	    System.out.println("Circle is created");
	    System.out.println("Color of circle is "+color);
     }
     Circle(double radius)
     {
    	 this.radius=radius;
    	 System.out.println("Radius of acircle is: " +radius);
     }
     double getRadius()
     {   
    	 return radius;
    	 
     }
     double getArea()
     {
    	double area=3.14*getRadius()*getRadius();
    	return area;
     }

}
