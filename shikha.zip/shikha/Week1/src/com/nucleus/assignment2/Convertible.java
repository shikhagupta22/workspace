package com.nucleus.assignment2;

public class Convertible extends Car
{
  boolean isHoodOpen;
  void display()
  {
	  System.out.println("Make of car: " + make +" Model: "+ model+ " Number of Doors: "+noOfDoor+" Is hood open:"+isHoodOpen);
  }
}
