package com.nucleus.assignment2;

public class SportCar extends Car
{ int noOfDoor=2;

}
