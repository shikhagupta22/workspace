package com.nucleus.assignment2;

public class Student 
{   String name;
    String id;
    double grade;
    Student(String id)
    { this.id=id;
    }
    Student(String id,String name )
    {
    	this(id);
    	this.name=name;
    }
    Student(String id,String name,double grade)
    {
	    this(id,name);
	    this.grade=grade;
    }
    void display()
    {
    	System.out.println("name=" + name + ", id=" + id + ", grade=" + grade);
    }
    void display(int hours)
    {   display();
    	System.out.println("hours: "+hours);
    }
	
	}
    


