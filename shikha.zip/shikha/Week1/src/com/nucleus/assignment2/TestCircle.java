package com.nucleus.assignment2;

public class TestCircle {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		new Circle();
		Circle c=new Circle(2.2);
		System.out.println("Area of acircle is: " +c.getArea());

	}

}
