package com.nucleus.assignment2;

public class Vehicle 
{
  int noOfWheel;
  int noOfPassenger;
  int model;
  String make;
  void display()
  { System.out.println("Make of car: " +make+" Model: "+ model+ " Number of wheels: "+noOfWheel+" Number of seats: "+noOfPassenger);
	  
  }
}
