package com.nucleus.assignment3;

public class Account 
{
	String custName;
	int accNo;
	String typeOfAcc;
	long bal;
	long deposit;
	void init(String custName,int accNo,String typeOfAcc,long bal)
	{
		this.custName=custName;
		this.accNo=accNo;
		this.typeOfAcc=typeOfAcc;
		this.bal=bal;
		
		
	}

	void deposit(long deposit)
	{
		this.bal+=deposit;
		System.out.println("Current balance is :"+  bal);
	}
	void display()
	{
		System.out.println(" "+custName+" "+accNo+" "+typeOfAcc+" "+this.bal);
				
	}

}