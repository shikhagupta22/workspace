package com.nucleus.assignment3;

public class Book 
{ int bookId=1021;
  String title="The Alchemist";
  String author="Paulo Coelho";
  int price=100;
  Book(int bookId,String title,String author,int price)
  {
	  this.bookId=bookId;
	  this.title=title;
	  this.author=author;
	  this.price=price;
  }

}
