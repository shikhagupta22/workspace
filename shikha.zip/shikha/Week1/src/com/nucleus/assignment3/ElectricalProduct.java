package com.nucleus.assignment3;

public class ElectricalProduct extends Product
{  String voltageRange;
   int wattage;
   ElectricalProduct(int productId,String name,String categoryId,int unitPrice,String voltageRange,int wattage)
   {
	   super(productId,name,categoryId,unitPrice);
	   this.voltageRange=voltageRange;
	   this.wattage=wattage;
	   
	   
   }
   void change(String voltageRange,int unitPrice)
   {
	   this.voltageRange=voltageRange;
	   this.unitPrice=unitPrice;
	
   }
@Override
public String toString() {
	return "ElectricalProduct [voltageRange=" + voltageRange + ", wattage="
			+ wattage + ", productId=" + productId + ", name=" + name
			+ ", categoryId=" + categoryId + ", unitPrice=" + unitPrice + "]";
}

   

}
