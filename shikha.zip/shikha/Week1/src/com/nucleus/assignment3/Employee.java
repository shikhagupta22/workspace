package com.nucleus.assignment3;

public class Employee 
{  int empId;
   String name;
   String desgn;
   int projectId;
   String phoneNumber;
   Employee(int empId,String name,String desgn,int projectId,String phoneNumber)
   {
	   this.empId=empId;
	   this.name=name;
	   this.desgn=desgn;
	   this.projectId=projectId;
	   this.phoneNumber=phoneNumber;
   }
   
}
