package com.nucleus.assignment3;

public class Employee1 
{  String name="Shikha";
   float salary=20000;
@Override
public String toString() {
	return "Employee1 [name=" + name + ", salary=" + salary + "]";
}
   

}
