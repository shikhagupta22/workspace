package com.nucleus.assignment3;

public class Executive extends Manager
{

	@Override
	public String toString() {
		return "Executive [ name=" + name + ",dept=" + dept + ", salary="
				+ salary + "]";
	}
  
}
