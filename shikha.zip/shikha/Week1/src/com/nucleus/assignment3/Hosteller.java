package com.nucleus.assignment3;

public class Hosteller extends Student
{    String hostelName;
     int roomNo;
     Hosteller(int stuId,String name,int courseId,String sex,String phoneNo,String hostelName,int roomNo)
     {
    	 super(stuId,name,courseId,sex,phoneNo);
    	 this.hostelName=hostelName;
    	 this.roomNo=roomNo;
     }
     void change(String hostelName,String phoneNo)
     {
    	 this.hostelName=hostelName;
    	 this.phoneNo=phoneNo;
     }
	@Override
	public String toString() {
		return "Hosteller [hostelName=" + hostelName + ", roomNo=" + roomNo
				+ ", stuId=" + stuId + ", name=" + name + ", courseId="
				+ courseId + ", sex=" + sex + ", phoneNo=" + phoneNo + "]";
	}
     

}
