package com.nucleus.assignment3;

public class Instructor extends Person
{
	float salary;
	Instructor(String name,int year,float salary)
	{
		super(name,year);
		this.salary=salary;
	}
	@Override
	public String toString() {
		return "Instructor [ name=" + name + ", year="
				+ year +", salary=" + salary + "]";
	}

}
