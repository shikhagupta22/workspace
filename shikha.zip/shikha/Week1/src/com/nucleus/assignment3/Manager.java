package com.nucleus.assignment3;

public class Manager extends Employee1
{
     String dept="Product";

	@Override
	public String toString() {
		return "Manager [ name=" + name + ",dept=" + dept + ", salary="
				+ salary + "]";
	}
     
}
