package com.nucleus.assignment3;

public class Periodical extends Book
{  String period="MAY-JUN";
   Periodical(int bookId,String title,String author,int price,String period)
   {
	   super(bookId,title, author, price);
	   this.period=period;
   }
   void change(int price,String period)
   {
	   this.price=price;
	   this.period=period;
	
   }
   
@Override
public String toString() {
	return "Periodical [period=" + period + ", bookId=" + bookId + ", title="
			+ title + ", author=" + author + ", price=" + price + "]";
}
   

}
