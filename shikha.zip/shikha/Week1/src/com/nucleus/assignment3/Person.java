package com.nucleus.assignment3;

public class Person 
{
	String name;
	int year;
	Person(String name,int year)
	{
		this.name=name;
		this.year=year;
	}

}
