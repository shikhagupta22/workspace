package com.nucleus.assignment3;

public class PracticalHead extends Employee
{   String practiceName;
    int noOfCustomers;
   
    PracticalHead(int empId,String name,String desgn,int projectId,String phoneNumber,String practiceName,int noOfCustomers)
    {
    	super(empId,name,desgn,projectId,phoneNumber);
    	this.practiceName=practiceName;
    	this.noOfCustomers=noOfCustomers;
    }
    void change(int noOfCustomers,String phoneNumber)
    {   this.noOfCustomers=noOfCustomers;
    	this.phoneNumber=phoneNumber;
    	
    	
    }

	@Override
	public String toString() {
		return "Practicalhead [practiceName=" + practiceName
				+ ", noOfCustomers=" + noOfCustomers + ", empId=" + empId
				+ ", name=" + name + ", desgn=" + desgn + ", projectId="
				+ projectId + ", phoneNumber=" + phoneNumber + "]";
	}
    

}
