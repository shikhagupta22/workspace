package com.nucleus.assignment3;

public class Product 
{  int productId=1232;
   String name="Bulb";
   String categoryId="21 A";
   int unitPrice=210;
   Product(int productId,String name,String categoryId,int unitPrice)
   {
	   this.productId=productId;
	   this.name=name;
	   this.categoryId=categoryId;
	   this.unitPrice=unitPrice;
   }
}
