package com.nucleus.assignment3;

public class Student 
{  int stuId;
   String name;
   int courseId;
   String sex;
   String phoneNo;
   Student(int stuId,String name,int courseId,String sex,String phoneNo)
   {
	   this.stuId=stuId;
	   this.name=name;
	   this.courseId=courseId;
	   this.sex=sex;
	  this.phoneNo=phoneNo; 
   }

}
