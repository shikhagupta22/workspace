package com.nucleus.assignment3;

public class Student1 extends Person
{
	String major;
	Student1(String name,int year,String major)
	{
		super(name,year);
		this.major=major;
	}
	@Override
	public String toString() {
		return "Student1 [name=" + name + ", year=" + year
				+ ", major=" + major + "]";
	}
	
	

}
