package com.nucleus.assignment3;
import java.util.*;
public class TestAccount 
{

	
	public static void main(String[] args) 
	{
		int ch,a,b;
		long deposit=0;
		do{
		System.out.println("MENU");
		System.out.println("Enter your account type");
		System.out.println("Press 1 for Current Account");
		System.out.println("Press 2 for Savings Account");
		System.out.println("Press 3 for exit");
		Scanner sc= new Scanner(System.in);
		ch=sc.nextInt();
		do{
		switch(ch)
		{
		case 1:
		       System.out.println("Press 1 for depositing money");
		       System.out.println("Press 2 for display balance");
		       System.out.println("Press 3 for check minimum balance ");
		       System.out.println("Press 0 for exit");
		       CurrentAcc c=new CurrentAcc();
		       c.init("Shikha",607123,"Current",20000);
		       a=sc.nextInt();
		       switch(a)
		       {
			       case 1:
			    	      System.out.println("Enter the amount you want to deposit");
			              deposit=sc.nextLong();
		                  c.deposit(deposit);
		                  c.display();
		                  break;
			       case 2:
		                  c.deposit(deposit);
			    	      c.display();
			              break;
			       case 3:c.checkBalance(c.minBalance);
			              break;
			       case 0: System.exit(0);
			       default:System.out.println("You pressed wrong number");       
		        }
		        break;
		        
		case 2:
		       System.out.println("Press 1 for depositing money");
		       System.out.println("Press 2 for display balance");
		       System.out.println("Press 3 for withdraw");
		       System.out.println("Press 4 for interest");
		       System.out.println("Press 0 for exit");
		       SavingsAcc s=new SavingsAcc();
		       s.init("Shikha",607123,"Current",20000);
		       b=sc.nextInt();
		       switch(b)
		       {
		       case 1:
		    	      System.out.println("Enter the amount you want to deposit");
		              deposit=sc.nextLong();
	                  s.deposit(deposit);
	                  s.display();
	                  break;
		       case 2:
	                  s.deposit(deposit);
		    	      s.display();
		              break;
			      case 3:System.out.println("Enter the amount you want to withdraw");
			             long with=sc.nextLong();
				         s.withdraw(with);
				         break;
			      case 4:s.compInterest(s.bal, 5, 2, 2);
			             break;
			      case 0:System.exit(0);
			      default:System.out.println("You pressed wrong number"); 
		        }
		        break;
		        }}while(ch==1||ch==2||ch==3||ch==4);
		
		System.exit(0);}while(ch==1||ch==2);

	}}

