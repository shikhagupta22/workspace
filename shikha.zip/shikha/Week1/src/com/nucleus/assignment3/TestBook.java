package com.nucleus.assignment3;

public class TestBook {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Periodical p=new Periodical(1021,"The Alchemist","Paulo Coelho",100,"May-Jun");
	    p.change(200,"JUN-JULY");
		System.out.println(p);

	}

}
