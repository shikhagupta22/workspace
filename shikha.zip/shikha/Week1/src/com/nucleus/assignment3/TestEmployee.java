package com.nucleus.assignment3;

public class TestEmployee 
{

	
	public static void main(String[] args) 
	{ PracticalHead p=new PracticalHead(121, "Shikha","Developer",23,"21322435","A2", 2);
	p.change(5,"A3");
	System.out.println(p);
	
	
	
		

	}

}
