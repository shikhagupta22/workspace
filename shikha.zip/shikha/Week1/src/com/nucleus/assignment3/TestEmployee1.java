package com.nucleus.assignment3;

public class TestEmployee1 {

	public static void main(String[] args) 
	{   Employee1 e1=new Employee1();
	    Manager m=new Manager();
	    Executive e=new Executive();
	    System.out.println(e1);
	    System.out.println(m);
	    System.out.println(e);

	}

}
