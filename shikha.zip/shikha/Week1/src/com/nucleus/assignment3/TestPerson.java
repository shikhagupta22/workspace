package com.nucleus.assignment3;

public class TestPerson 
{

	
	public static void main(String[] args) 
	{
		Student1 s=new Student1("Shikha",2014,"CS");
		System.out.println(s);
		Instructor i=new Instructor("Shikha",2014,25000);
		System.out.println(i);

	}

}
