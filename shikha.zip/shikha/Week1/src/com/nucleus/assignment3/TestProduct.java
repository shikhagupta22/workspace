package com.nucleus.assignment3;

public class TestProduct 
{

	public static void main(String[] args) 
	{
		ElectricalProduct e=new ElectricalProduct(1232,"Bulb","21 A",210,"200V-300V",250);
		e.change("400V-500V", 250);
		System.out.println(e);

	}

}
