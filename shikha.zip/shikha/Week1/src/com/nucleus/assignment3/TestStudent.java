package com.nucleus.assignment3;

public class TestStudent 
{

	
	public static void main(String[] args) 
	{ Hosteller h=new Hosteller(123,"Shikha",21,"Female","9352678492","ipec hostel",203);
	  h.change("ITS hostel", "9810356246");
	  System.out.println(h);
	  



	}

}
