package com.nucleus.assignment3;

public class TestVehicle {

	
	public static void main(String[] args) 
	{   Truck t=new Truck(2231,"2011","Maruti","Grey",100);
	    t.change("Brown",200);
		System.out.println(t);

	}

}
