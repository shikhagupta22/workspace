package com.nucleus.assignment3;

public class Truck extends Vehicle 
{ int loadCap;
  Truck(int vehicleNo,String model,String manufacturer,String color,int loadcap)
  {
	  super(vehicleNo,model,manufacturer,color);
	  this.loadCap=loadcap;
  }
  void change(String color,int loadCap)
  { 
	  this.color=color;
      this.loadCap=loadCap;
  }
@Override
public String toString() {
	return "Truck [loadCap=" + loadCap + ", vehicleNo=" + vehicleNo
			+ ", model=" + model + ", manufacturer=" + manufacturer
			+ ", color=" + color + "]";
}
  
  

}
