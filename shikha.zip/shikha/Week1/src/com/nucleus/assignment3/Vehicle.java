package com.nucleus.assignment3;

public class Vehicle 
{ int vehicleNo;
  String model;
  String manufacturer;
  String color;
  Vehicle(int vehicleNo,String model,String manufacturer,String color)
  {
	  this.vehicleNo=vehicleNo;
	  this.model=model;
	  this.manufacturer=manufacturer;
	  this.color=color;
  }

}
