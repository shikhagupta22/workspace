package com.nucleus.assignment4;

public class Category 
{
	String modelOfCategory(String name)
	{  if(name.equals("SUV"))
	   {
		return "TATA SAFARI";
	   }
	else if(name.equals("SEDAN"))
	   {
		return "TATA INDIGO";
	   }
	else if(name.equals("ECONOMY"))
	   {
		return "TATA INDICA";
	   }
	else if(name.equals("MINI"))
	   {
		return "TATA NANO";
	   }
	else
	{
		return "match not found";
	}
		
	}

}
