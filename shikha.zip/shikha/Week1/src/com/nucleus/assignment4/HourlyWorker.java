package com.nucleus.assignment4;

public class HourlyWorker extends Worker
{
	void computePay(int hours)
	{
		Float pay=hours*salaryRate;
		System.out.println("Salary for Hourly worker is:"+pay);
		
	}

}
