package com.nucleus.assignment4;

public class Overload 
{
  void volume(float side)
  {
	  System.out.println("Volume of cube is :"+(side*side*side));
  }
  void volume(float r,float h)
  {
	  System.out.println("Volume of cylinder is:"+(3.14*r*r*h));
  }
  void volume(float l,float b,float h)
  {
	  System.out.println("Volume of rectangle is:"+(l*b*h));
  }
}
