package com.nucleus.assignment4;

public class SalariedWorker extends Worker
{
	void computePay(int hours)
	{   hours=40;
		Float pay=hours*salaryRate;
		System.out.println("Salary for Salary worker is:"+pay);
		
	}

}
