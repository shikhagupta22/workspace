package com.nucleus.assignment4;

public class TestCategory 
{

	
	public static void main(String[] args) 
	{
		Category c=new Category();
		String category;
		category=c.modelOfCategory("SUV");
		System.out.println("Category for SUV is:"+category);
		category=c.modelOfCategory("SEDAN");
		System.out.println("Category for SEDAN is:"+category);
		category=c.modelOfCategory("ECONOMY");
		System.out.println("Category for ECONOMY is:"+category);
		category=c.modelOfCategory("MINI");
		System.out.println("Category for MINI is:"+category);
		

	}

}
