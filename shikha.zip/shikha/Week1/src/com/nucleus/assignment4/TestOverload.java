package com.nucleus.assignment4;

public class TestOverload 
{

	
	public static void main(String[] args)
    {
		Overload o=new Overload();
		o.volume(3);
		o.volume(5,3);
		o.volume(2,4,2);
		

	}

}
