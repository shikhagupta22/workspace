package com.nucleus.assignment4;

public class TestQuestion1 
{

	public static void main(String[] args) 
	{
		question1 q=new question1();
		q.power(2,3);
		q.power(2.1, 2);
		q.power(2.13, 4);		

	}

}
