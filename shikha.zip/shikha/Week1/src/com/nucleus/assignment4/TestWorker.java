package com.nucleus.assignment4;

public class TestWorker 
{

	
	public static void main(String[] args)
    {
		HourlyWorker h=new HourlyWorker();
        h.computePay(45);
        SalariedWorker s=new SalariedWorker();
        s.computePay(45);
        
	}

}
