package com.nucleus.assignment4;

public class Worker 
{
	String worker;
	float salaryRate=350;

}
