package com.nucleus.assignment4;

public class question1 
{
	void power(int n,int p)
	{
		int val=0;
		for(int i=0;i<p;i++)
		{
			
			val=val+n*n;
			
		}
		System.out.println("Result for integer:"+val);
	}
	void power(float n,int p)
	{   float val=0;
		for(int i=0;i<p;i++)
		{
			
			val=val+n*n;
			
		}
		System.out.println("Result for float:"+val);
	}
	void power(double n,int p)
	{
		double val=0;
		for(int i=0;i<p;i++)
		{
			
			val=val+n*n;
			
		}
		System.out.println("Result for double:"+val);
	}

}
