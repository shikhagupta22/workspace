public class First 
{
                 
	public static void CBSE (int x) 
	{
                
		if (x < 100) 
			CBSE (x + 10);
		System.out.println(x-1);
                     
		//return (x - 1);
                        
	}
      public static void main (String[] args)
      {
     First.CBSE(60);
                        
      }
                           
}