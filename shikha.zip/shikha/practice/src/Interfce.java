
public interface Interfce 
{
	void displayProduct(int a);

}
