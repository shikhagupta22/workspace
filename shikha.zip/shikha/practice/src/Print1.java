
class A
{
	int x=10;
	int y;
	{
		y=11;
	}
	void run()
	{
		System.out.println("class A");
	}
	void run1()
	{
		
	}
	

}
class B extends A
{
	int x=20;
	void run()
	{
		System.out.println("class B");
	}
	void run2()
	{
		
	}
	
}
public class Print1
{
	public static void main(String[] args) 
	{
		B a=new B();
		a.run();
		System.out.println(a.x);
		System.out.println(a.y);

	}
	
}
