
public class ProdInf extends Product implements Interfce
{
    
	

	public static void main(String[] args) 
	{
		ProdInf p=new ProdInf();
		int d=p.calProduct(2,3);
		p.displayProduct(d);

	}

	@Override
	public void displayProduct(int a) 
	{
		System.out.println(a);
		
	}



}
