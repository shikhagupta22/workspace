
public class Product 
{ int calProduct(int a,int b)
	{ int c=a*b;
	return c;
	
	}

	
}
