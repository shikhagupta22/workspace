
public class Strings 
{
	String s="abc";

	public static void main(String[] args) 
	{
		Strings str=new Strings();
		String str1=str.s+"d";
		System.out.println(str1);

	}

}
