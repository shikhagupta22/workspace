package com.nucleus;

public class A {
	void m()
	{
		System.out.println("m func");
	}
	void n()
	{
		System.out.println("n func");
		m();
	}
	

	
	public static void main(String[] args) {
		new A().n();
		new A().m();
		
}}
