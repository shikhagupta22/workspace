package com.nucleus;

public class Address 
{   String city;
    String state;
    String code;
    Address(String city,String state ,String code)
    {
    	this.city=city;
    	this.state=state;
        this.code=code;
    }
	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", code=" + code
				+ "]";
	}
    


}
