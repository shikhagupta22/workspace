package com.nucleus;

public class Animal
{
	void eat()
 {System.out.println("eat");}	
}
class Dog extends Animal
{
 void bark()
 {
	 System.out.println("bark");
 }
}
class BabyDog extends Animal
{
 void weep()
 {
	 System.out.println("weep");
 }
}

 
