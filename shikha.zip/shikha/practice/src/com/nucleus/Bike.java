package com.nucleus;

public class Bike extends Vehicle
{ int nOfTyres;
 Bike(String name,String model,int nOfTyres)
 {
	 super(name,model);
	 this.nOfTyres=nOfTyres;
 }
@Override
public String toString() {
	return "Bike [nOfTyres=" + nOfTyres + ", name=" + name + ", model=" + model
			+ "]";
}
 
public static void main(String args[])
{
	Bike b=new Bike("pulsar","2111",2);
	System.out.println(b);
}

}
