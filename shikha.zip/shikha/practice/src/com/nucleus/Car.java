package com.nucleus;

public class Car extends Vehicle
{
	int nOfTyres;
	String color;
	 Car(String name,String model,int nOfTyres,String color)
	 {
		 super(name,model);
		 this.nOfTyres=nOfTyres;
		 this.color=color;
	 }
	@Override
	public String toString() {
		return "Car [nOfTyres=" + nOfTyres + ", color=" + color + ", name="
				+ name + ", model=" + model + "]";
	}
	public static void main(String args[])
	{
		Car c=new Car("baleno","top",2,"mettalic grey");
		System.out.println(c);
	}
}
