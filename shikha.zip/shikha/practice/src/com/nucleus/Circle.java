package com.nucleus;

public class Circle 
{  Operation op;
   double pi=3.14;
   double area()
   {
	   op=new Operation();
	   double val=op.square(3);
	   double value= pi*val;
	   return value;
	   
   }
	
	public static void main(String args[])
	{
		Circle c=new Circle();
		double value1=c.area();
		System.out.println(value1);
	}

}
