package com.nucleus;

public class Contact 
{   String stdCode;
    String number;
    Contact(String stdCode,String number)
    {   this.stdCode=stdCode;
        this.number=number;
    	
    }
	@Override
	public String toString() {
		return "Contact [stdCode=" + stdCode + ", number=" + number + "]";
	}
    
}
