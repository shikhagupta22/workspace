package com.nucleus;

public class Course extends Student
{   int courseId;
    String courseName;
    Course(int stuId, String stuName,int courseId ,String courseName)
    {
    	super(stuId,stuName);
    	this.courseId=courseId;
    	this.courseName=courseName;
    }
    

}
