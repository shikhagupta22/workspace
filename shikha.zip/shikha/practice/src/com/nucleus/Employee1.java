package com.nucleus;

abstract class Employee1 extends Person1
{  String dept;
Employee1(int personId,String personName,String dept)
{super(personId,personName);
this.dept=dept;
	}
abstract void check(Employee1 e);
/*@Override
public String toString() {
	return "Employee1 [dept=" + dept + ", personId=" + personId
			+ ", PersonName=" + personName + "]";
}*/


}
