package com.nucleus;

public class Exam extends Course
{ int examId;
  String examName;
  Exam(int stuId,String stuName,int courseId ,String courseName,int examId,String examName)
  {
  	super(stuId, stuName, courseId, courseName);
  	this.examId=examId;
  	this.examName=examName;
  }
@Override
public String toString() {
	return "Exam [examId=" + examId + ", examName=" + examName + ", courseId="
			+ courseId + ", courseName=" + courseName + ", stuId=" + stuId
			+ ", stuName=" + stuName + "]";
}
  


}
class B
{
	public static void main(String args[])
	{
		Exam e=new Exam(1,"shikha",2,"Btech",3,"Java");
		System.out.println(e);
	}
}
