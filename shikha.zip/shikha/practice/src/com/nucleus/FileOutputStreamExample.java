package com.nucleus;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamExample 
{

	public static void main(String[] args) throws IOException 
	{
		FileOutputStream f=new FileOutputStream("test1.txt");
		f.write((char)2);
		f.flush();
		System.out.println("sucecess");
		
		
		

	}

}
