package com.nucleus;

class FinalKey 
{
	int a;
	FinalKey(int a)
	{
		this.a=a;
	}}