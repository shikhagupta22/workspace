package com.nucleus;

public class Manager1 extends Employee1 
{  int manage;
   Manager1(int personId,String personName,String dept,int manage)
      {super(personId,personName,dept);
       this.manage=manage;
	  }
	void print(Person1 p)
      {  System.out.println(p);
	  }
	
@Override
	public String toString() {
		return "Manager1 [manage=" + manage + ", dept=" + dept + ", personId="
				+ personId + ", personName=" + personName + "]";
	}
void check(Employee1 e)
{
System.out.println(e);
}

	
	public static void main(String[] args) 
	{   
		Manager1 m=new Manager1(1,"shikha","Developer",10);
		System.out.println(m);
		m.check(m);
		m.print(m);
		

	}

}
