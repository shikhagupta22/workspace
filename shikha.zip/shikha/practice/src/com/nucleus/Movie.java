package com.nucleus;

public class Movie {String name;
String rating;
String star;
int count;
Movie(String name,String rating,String star)
{
	this.name=name;
	this.rating=rating;
	this.star=star;
}
Movie(String name,String rating)
{
	this.name=name;
	this.rating=rating;
}
void display()
{    int count=count();
	if(count==5)
	{
		System.out.println(name+"  "+"Rating is 5");
	}
	else
	{
		System.out.println("rating is not 5");
	}
}
int count()
{
	int count1=rating.length();
	return count1;
}

}
