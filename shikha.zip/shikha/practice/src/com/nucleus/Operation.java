package com.nucleus;

public class Operation 
{
   int square(int n)
   {
	   return n*n;
   }
}
