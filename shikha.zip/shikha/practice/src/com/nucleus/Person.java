package com.nucleus;

public class Person 
{ String name;
  Contact con;
  Contact con1;
  Person(String name,Contact con)
  {
	  
	  this.name=name;
	  this.con=con;
  }
  /*Person(String name,Contact con,Contact con1)
  {
	  
	  this.name=name;
	  this.con=con;
	  this.con1=con1;
  }*/

public static void main(String args[])
{   Contact con=new Contact("011","22570810");
/*Contact con1=new Contact("011","22570810");*/
	Person p= new Person("shikha",con);
	System.out.println(p);
}
@Override
public String toString() {
	return "Person [name=" + name + ", con=" + con + ", con1=" + con1 + "]";
}





}
