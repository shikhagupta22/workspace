package com.nucleus;

abstract class Person1 
{ int personId;
String personName;
Person1(int personId,String personName)
{this.personId=personId;
this.personName=personName;	}
abstract void print(Person1 p);
/*@Override
public String toString() {
	return "Person1 [personId=" + personId + ", PersonName=" + personName + "]";
}*/

}
