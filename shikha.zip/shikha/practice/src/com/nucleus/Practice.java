package com.nucleus;
public class Practice 
{


	public static void main(String args[])
	{  
		 TestJoin t1=new TestJoin(); 
		 Test t2=new Test();  
		 t1.start();  
		 try{  
		  t1.join(1500);  
		 }catch(Exception e){System.out.println(e);}  
		  
		 t1.start();  
		 //t2.start();  
		 }  

}
class TestJoin extends Thread
{
	 public void run(){  
		  for(int i=1;i<=5;i++){  
		   try{  
		    Thread.sleep(500);  
		   }catch(Exception e){System.out.println(e);}  
		  System.out.println("Thread 1:"+i);  
		  }  

}
class Test extends Thread
{
	 public void run(){  
		  for(int i=1;i<=5;i++){  
		   try{  
		    Thread.sleep(500);  
		   }catch(Exception e){System.out.println(e);}  
		  System.out.println("Thread 2:"+i);  
		  }  
}

}

}
