package com.nucleus;

public class PrntMthd 
{    void print(String stmt)
    {
	System.out.println(stmt);
	}
void print(int arr[])
{for(int i=0;i<4;i++)
	{
	  System.out.println(arr[i]);
	}

}
void print()
{
System.out.println("hello");
}

	
	public static void main(String[] args) 
	{
		int arr[]={1,7,9,5};
		PrntMthd p=new PrntMthd();
		p.print(arr);
		p.print("shikha");
		p.print();

	}

}
