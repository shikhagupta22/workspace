package com.nucleus;

public class SingleInh 
{
  
}
