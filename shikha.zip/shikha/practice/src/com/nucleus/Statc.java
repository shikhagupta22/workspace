package com.nucleus;

public class Statc {
	int count=0;
	Statc()
	{
		count++;
		System.out.println(count);
	}

}
