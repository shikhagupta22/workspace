package com.nucleus;

public class Student 
{ int stuId;
  String stuName;
  Student(int stuId,String stuName)
  {
	  this.stuId=stuId;
	  this.stuName=stuName;
  }
  
  void display()
  {
	  System.out.println("Student Id:"+ stuId +"Student Name:"+stuName);
  }

}
