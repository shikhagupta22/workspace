package com.nucleus;

public class SuperTest 
{     

	
	public static void main(String[] args) 
	{
      Dg d=new Dg();
      d.printColor();


	}

}
class Anmal

{  String color="white";
	
}
class Dg extends Anmal

{
	String color="black";
	void printColor()
	{
		System.out.println(color);
		System.out.println(super.color);
	}
}
