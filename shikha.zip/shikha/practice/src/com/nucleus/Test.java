package com.nucleus;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TicketsPro t=TicketsPro.createTicket(1, "shikha", "contact", "date");
		TicketsPro t2=TicketsPro.createTicket(1, "s", "contact", "date");
		TicketsPro t3=TicketsPro.createTicket(1, "shkha", "contact", "date");
		System.out.println(t);
		System.out.println(t2);
		System.out.println(t3);
		

	}

}
