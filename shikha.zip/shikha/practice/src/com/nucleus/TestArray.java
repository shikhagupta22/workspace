package com.nucleus;

public class TestArray 
{  void min(int arr[])
   {int i;
	int min=arr[0];
	for(i=0;i<4;i++)
	if(min>arr[i])
	{
		min=arr[i];
	}
	System.out.println(min);
   }

	public static void main(String[] args) 
	{
		int arr[]={2,-1,1,5};
        TestArray t=new TestArray();
        t.min(arr);
	}

}
