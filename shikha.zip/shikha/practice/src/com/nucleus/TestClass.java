package com.nucleus;

public class TestClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	Statc s=new Statc();
	Statc s1=new Statc();

	}

}
