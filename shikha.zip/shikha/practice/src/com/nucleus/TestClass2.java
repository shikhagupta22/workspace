package com.nucleus;

public class TestClass2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Tickets t1=new Tickets(1,"shikha","9876765438","23/2/18");
		System.out.println(t1);
		Tickets t2=new Tickets(2,"shikha","9876765438","23/2/18");
		System.out.println(t2);
		Tickets t3=new Tickets(3,"shikha","9876765438","23/2/18");
		System.out.println(t3);
		Tickets t4=new Tickets(4,"shikha","9876765438","23/2/18");
		System.out.println(t4);
		Tickets t5=new Tickets(5,"shikha","9876765438","23/2/18");
		System.out.println(t5);
		Tickets t6=new Tickets(6,"shikha","9876765438","23/2/18");
		System.out.println(t6);
		Tickets t7=new Tickets(7,"shikha","9876765438","23/2/18");
		System.out.println(t7);
		Tickets t8=new Tickets(8,"shikha","9876765438","23/2/18");
		System.out.println(t8);
		Tickets t9=new Tickets(9,"shikha","9876765438","23/2/18");
		System.out.println(t9);
		Tickets t10=new Tickets(10,"shikha","9876765438","23/2/18");
		System.out.println(t10);
		Tickets t11=new Tickets(11,"shikha","9876765438","23/2/18");
		System.out.println(t11);
		Tickets t12=new Tickets(12,"maj","9876765438","23/2/18");
		System.out.println(t12);

	}

}
