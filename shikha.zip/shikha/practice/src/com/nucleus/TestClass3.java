package com.nucleus;

public class TestClass3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Movie m=new Movie("Avengers","*****","####");
		m.display();
		Movie m1=new Movie("Iron man","****");
		m1.display();
		

	}

}
