package com.nucleus;

class TestInheritance
{ 
	public static void main(String args[])
	{
		BabyDog d=new BabyDog();
		d.eat();
		d.weep();
		Dog b=new Dog();
		b.eat();
		b.bark();
	}
} 

