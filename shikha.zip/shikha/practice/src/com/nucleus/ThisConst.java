package com.nucleus;

public class ThisConst {

	int id;
	String name;
	int fee;
	ThisConst(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	ThisConst(int id,String name,int fee)
	{
		this(id,name);
		this.fee=fee;
		
		}
	
	public static void main(String[] args) 
	{
		ThisConst t=new ThisConst(21,"shikha",4300);
		System.out.println(t);

	}
	@Override
	public String toString() {
		return "ThisConst [id=" + id + ", name=" + name + ", fee=" + fee + "]";
	}

}
