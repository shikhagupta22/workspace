package com.nucleus;

public class ThisKey {

	ThisKey()
	{   this(5);
		System.out.println("default");
	}
	ThisKey(int x)
	{
		
		System.out.println(x);
	}
	public static void main(String[] args) 
	{
	  new ThisKey();	

	}

}
