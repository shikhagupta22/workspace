package com.nucleus;

public class Tickets {

	static int counter=0;
	static int ticketLimit=10;
	int id;
    String name;
   String contact;
   String date;
    
    Tickets(int id,String name,String contact,String date)
    { System.out.println("object created");
    	this.id=id;
      this.name=name;
      this.contact=contact;
      this.date=date;
      counter++;
      
    }
   
    { 
    	if(counter>=ticketLimit)
    		{System.out.println("limit exceed");
    		System.exit(0);}
    	else{
    		System.out.println("Tickets Available");
    	}
    }
	@Override
	public String toString() {
		return "Tickets [id=" + id + ", name=" + name + ", contact=" + contact
				+ ", date=" + date + "]";
	}


}
