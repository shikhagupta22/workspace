package com.nucleus;

public class TicketsPro {
	static int counter=1;
	static int ticketLimit=10;
	int id;
    String name;
   String contact;
   String date;
   TicketsPro(int id,String name,String contact,String date){
	   
	   this.id=id;
	   this.name=name;
	   this.contact=contact;
	   this.date=date;
	   counter++;
   }
   static TicketsPro createTicket(int id,String name,String contact,String date)
   {
	   if(counter<3)
	   {
		   return new TicketsPro(id,name,contact,date);
	   }
	   else
	   {
		   return null;
	   }
   }
@Override
public String toString() {
	return "TicketsPro [id=" + id + ", name=" + name + ", contact=" + contact
			+ ", date=" + date + "]";
}
   
}
