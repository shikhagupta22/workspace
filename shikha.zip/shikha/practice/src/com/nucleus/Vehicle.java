package com.nucleus;

public class Vehicle 
{
 String name;
 String model;
 Vehicle(String name,String model)
 {
	 this.name=name;
	 this.model=model;
 }
/*@Override
public String toString() {
	return "Vehicle [name=" + name + ", model=" + model + "]";
}*/
 
	
}
