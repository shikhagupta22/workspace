package com.nucleus;

public class Vendor 
{ 
	String vendorId;
	String vendorName;
	Address adr;
	Vendor(String vendorId,String vendorName,Address adr)
	{
		this.vendorId=vendorId;
		this.vendorName=vendorName;
		this.adr=adr;
	}
	@Override
	public String toString() {
		return "Vendor [vendorId=" + vendorId + ", vendorName=" + vendorName
				+ ", adr=" + adr + "]";
	}
	public static void main(String args[])
	{
	   Address adr=new Address("New Delhi","Delhi","110032");
	   Vendor vdr=new Vendor("1","Shikha",adr);
	   System.out.println(vdr);
	   System.out.println(adr);
	}
	
		
	

}
