package com.nucleus.core;

public class Employee implements Cloneable 
{
	int eid;
	String name;
	public void show()
	{
		System.out.println(eid+" : "+name);
	}
	@Override
	protected Object clone() throws CloneNotSupportedException 
	{
		return super.clone();
	}

}
