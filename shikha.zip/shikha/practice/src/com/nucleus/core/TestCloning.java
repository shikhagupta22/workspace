package com.nucleus.core;

public class TestCloning 
{
	public static void main(String args[]) throws CloneNotSupportedException
	{
		Employee e1=new Employee();
		e1.eid=23;
		e1.name="Shikha";
		Employee e2=new Employee();
		e2.eid=24;
		e2.name="Tripti";
		Employee e3=(Employee)e1.clone();
		e3.eid=43;
		e1.show();
		e2.show();
		e3.show();
		System.out.println(e1==e3);
	}
	

}
