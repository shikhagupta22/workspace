package com.nucleus.core;
class Outer
{
	int a=5;
	public void show()
	{
		System.out.println(a);
	}
	static class Inner
	{
		public void display()
		{
			System.out.println("Hello");
		}
		
	}
}
public class TestInner 
{
    public static void main(String args[])
    {
    	Outer obj=new Outer();
    	obj.show();
    	Outer.Inner obj1=new Outer.Inner();
    	obj1.display();
    }
	

}
