package com.nucleus.practice;

public class A 
{
	private int a=5;
	
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	protected int value()
	{
		return 2;
	}

}
