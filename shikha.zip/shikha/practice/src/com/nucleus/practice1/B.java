package com.nucleus.practice1;

import com.nucleus.practice.A;

public class B extends A
{

	/*@Override
	protected int value() {
		// TODO Auto-generated method stub
		return super.value();
	}*/
	
}
