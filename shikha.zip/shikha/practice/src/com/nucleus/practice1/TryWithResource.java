package com.nucleus.practice1;

public class TryWithResource 
{

	public static void main(String[] args) 
	{
		{
			System.out.println("Hello");
		}
	}

}
