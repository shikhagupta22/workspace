package com.nucleus.serial;

import java.io.Serializable;

public class Person implements Serializable
{
	int id;
	String name;
	float salary;
	Person(int id,String name,float salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

}
