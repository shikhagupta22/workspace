package com.nucleus.serial;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class SerializePerson 
{
	public static void main(String args[]) throws IOException, ClassNotFoundException
	{
		Person p=new Person(23,"shikha",4000);
		FileOutputStream fos=new FileOutputStream("d:/shikhaserial.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(p);
		System.out.println("Success");
		FileInputStream fis=new FileInputStream("d:/shikhaserial.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Person p1=(Person)ois.readObject();
		System.out.println(p1);
	}

}
