package com.nucleus.staticpractice;

import java.io.Serializable;

public class Customer implements Serializable
{
	static int id;
	String name;
	String name1="shikha";
	int salary;
	static
	{
		id=4;
	}
}
