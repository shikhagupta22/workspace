package com.nucleus.staticpractice;

public class TestCustomer 
{
	public static void main(String args[])
	{
		Customer cust1=new Customer();
		Customer cust2=new Customer();
		Customer cust3=new Customer();
	    cust1.name="shikha";
	    cust1.salary=300;
	    cust2.name="shikha";
	    cust2.salary=300;
	    cust3.name="Golu";
	    System.out.println(cust1.salary==cust2.salary);
	    System.out.println(cust1.equals(cust2));
	}
	
}
